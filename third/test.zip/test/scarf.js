// این کد را در یک فایل HTML قرار دهید یا در کنسول مرورگر اجرا کنید
fetch('http://127.0.0.1:8000/products/product_list/')
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok ' + response.statusText);
        }
        return response.json();  // تبدیل پاسخ به JSON
    })
    .then(data => {
        console.log(data);  // نمایش داده‌های دریافت شده در کنسول

        // برای مثال می‌توانید داده‌ها را به صورت لیست در HTML نمایش دهید
        const productList = document.getElementById('product-list');  // فرض کنید یک المنت با id="product-list" دارید
        data.forEach(product => {
            const listItem = document.createElement('li');
            listItem.textContent = `${product.name}: ${product.description} - $${product.price}`;
            productList.appendChild(listItem);
        });
    })
    .catch(error => {
        console.error('There has been a problem with your fetch operation:', error);
    });
