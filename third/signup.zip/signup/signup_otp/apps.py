from django.apps import AppConfig


class SignupOtpConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'signup_otp'
